-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: corp
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` int NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT=' product_id	Код продукта\ndescription	Название продукта\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (100860,'Батут каркасный'),(100861,'Комплект дартс Start Line SLP Home-Play'),(100870,'Скандинавские палки / для скандинавской ходьбы'),(100871,'Набор для настольного тенниса ракетка (2шт), мяч (3шт), сетка с креплением'),(100890,'Теннисный стол'),(101860,'Гантель разборная (наборная) FITMAN DAF-2024 10.7'),(101863,'Мяч для настольного тенниса'),(102130,'Ракетка для настольного тенниса'),(102132,'Перчатки вратарские Torres Training'),(102134,'Ворота футбольные Mini '),(102136,'Набор для плавания'),(103120,'Протеиновое печенье FitnesShock АССОРТИ CRISPY'),(103121,'Сетка баскетбольная'),(103130,'Мяч баскетбольный Torres'),(103131,'Мяч волейбольный Mikasa, размер 5, цвет бел-син-желт'),(103140,'Мяч волейбольный Mikasa официальный мяч FIVB'),(103141,'Манишка Torres двухсторонняя'),(104350,'Мяч футбольный Adidas'),(104351,'Лестница для тренировок'),(104352,'Баскетбольная стационарная стойка '),(104360,'Баскетбольный щит'),(104361,'Кольцо баскетбольное R3 45 см'),(104362,'Ворота футбольные'),(105123,'Ворота игровые 10ft пластик'),(105124,'Робот баскетбольный для подачи мячей'),(105125,'Шапочка для плавания'),(105126,'Трубка плавательная'),(105127,'Ласты Salvas'),(105128,'Маска для плавания'),(200376,'Сетка для настольного тенниса'),(200380,'Беговая дорожка Orlauf Owl для дома, складная');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-24 12:05:45
