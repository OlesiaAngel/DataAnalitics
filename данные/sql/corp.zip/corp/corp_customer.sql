-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: corp
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `zip_code` varchar(9) DEFAULT NULL,
  `area_code` smallint DEFAULT NULL,
  `phone_number` int DEFAULT NULL,
  `salesperson_id` smallint DEFAULT NULL,
  `credit_limit` decimal(9,2) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `customer_FK1` (`salesperson_id`),
  CONSTRAINT `customer_FK1` FOREIGN KEY (`salesperson_id`) REFERENCES `employee` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT=' customer_id	Код покупателя\nname	Название покупателя\naddress	Адрес\ncity	Город\nstate	Штат\nzip_code	Почтовый код\narea_code	Код региона\nphone_number	Телефон\nsalesperson_id	Код сотрудника-продавца, обслуживаю-щего данного покупателя\ncredit_limit	Кредит для покупателя\ncomments	Примечания\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (100,'JOCKSPORTS','345 VIEWRIDGE','BELMONT','CA','96711',415,5986609,7844,5000.00,'С очень дружелюбными людьми приятно работать - торговому представителю нравится, когда его зовут Майк.'),(101,'TKB SPORT SHOP','490 BOLI RD.','REDWOOD CITY','CA','94061',415,3681223,7521,10000.00,'Представитель позвонил 5/8 по поводу изменения заказа - свяжитесь с отделом доставки.'),(102,'VOLLYRITE','9722 HAMILTON','BURLINGAME','CA','95133',415,6443341,7654,7000.00,'Компания активно продвигается по службе, начиная с 10/89. Готовьтесь к крупным заказам в выходные дни'),(103,'JUST TENNIS','HILLVIEW MALL','BURLINGAME','CA','97544',415,6779312,7521,3000.00,'Свяжитесь с представителем по поводу новой линейки теннисных ракеток.'),(104,'EVERY MOUNTAIN','574 SURRY RD.','CUPERTINO','CA','93301',408,9962323,7499,10000.00,'Клиент с высокой долей рынка (23%) благодаря агрессивной рекламе.'),(105,'K + T SPORTS','3476 EL PASEO','SANTA CLARA','CA','91003',408,3769966,7844,5000.00,'Имеет тенденцию заказывать большое количество товаров сразу. Бухгалтерия рассматривает возможность запуска'),(106,'SHAPE UP','908 SEQUOIA','PALO ALTO','CA','94301',415,3649777,7521,6000.00,'Интенсивная поддержка. Заказывает небольшие количества (< 800) товаров за один раз.'),(107,'WOMENS SPORTS','VALCO VILLAGE','SUNNYVALE','CA','93301',408,9674398,7499,10000.00,'Первый магазин спортивных товаров, ориентированный исключительно на женщин. Необычная рекламная акция'),(108,'NORTH WOODS HEALTH AND FITNESS SUPPLY CENTER','98 LONE PINE WAY','HIBBING','MN','55649',612,5669123,7844,8000.00,''),(201,'STADIUM SPORTS','47 IRVING PL.','NEW YORK','NY','10003',212,5555335,7557,10000.00,'Большой универсальный спортивный магазин с богатой клиентской базой.'),(202,'HOOPS','2345 ADAMS AVE.','LEICESTER','MA','01524',508,5557542,7820,5000.00,'Специализируется на баскетбольном снаряжении.'),(203,'REBOUND SPORTS','2 E. 14TH ST.','NEW YORK','NY','10009',212,5555989,7557,10000.00,'Следите за предложением о продвижении по службе.'),(204,'THE POWER FORWARD','1 KNOTS LANDING','DALLAS','TX','75248',214,5550505,7560,12000.00,'Большая площадь помещения.  Предпочитает иметь под рукой большое количество инвентаря.'),(205,'POINT GUARD','20 THURSTON ST.','YONKERS','NY','10956',914,5554766,7557,3000.00,'Огромный потенциал для заключения эксклюзивного соглашения.'),(206,'THE COLISEUM','5678 WILBUR PL.','SCARSDALE','NY','10583',914,5550217,7557,6000.00,'Свяжитесь с представителем по поводу новых продуктовых линеек.'),(207,'FAST BREAK','1000 HERBERT LN.','CONCORD','MA','01742',508,5551298,7820,7000.00,'Клиенту требуются письменные ценовые предложения, прежде чем делать заявки на покупку.'),(208,'AL AND BOB\'S SPORTS','260 YORKTOWN CT.','AUSTIN','TX','78731',512,5557631,7560,4000.00,'Очень личные агенты по закупкам - Шэрон и Скотт.'),(211,'AT BAT','234 BEACHEM ST.','BROOKLINE','MA','02146',617,5557385,7820,8000.00,'Есть открытый заказ на покупку на сумму 3000 долларов.  Отправляем немедленно по запросу.'),(212,'ALL SPORT','1000 38TH ST.','BROOKLYN','NY','11210',718,5551739,7600,6000.00,'Заключайте контракт - возможный кандидат на заключение соглашений о закупках на большие объемы.'),(213,'GOOD SPORT','400 46TH ST.','SUNNYSIDE','NY','11104',718,5553771,7600,5000.00,'Возможно, переезжает в более крупное место.'),(214,'AL\'S PRO SHOP','45 SPRUCE ST.','SPRING','TX','77388',713,5555172,7564,8000.00,'Целевой рынок - серьезные спортсмены.'),(215,'BOB\'S FAMILY SPORTS','400 E. 23RD','HOUSTON','TX','77026',713,5558015,7654,8000.00,'Целевой рынок - случайные спортсмены и спортсмены выходного дня.  Предлагает большой выбор.'),(216,'THE ALL AMERICAN','547 PRENTICE RD.','CHELSEA','MA','02150',617,5553047,7820,5000.00,'Клиент предпочитает, чтобы ему звонили между 10 и 12.'),(217,'HIT, THROW, AND RUN','333 WOOD COURT','GRAPEVINE','TX','76051',817,5552352,7564,6000.00,'The client prefers to be called between 10 and 12.'),(218,'THE OUTFIELD','346 GARDEN BLVD.','FLUSHING','NY','11355',718,5552131,7820,4000.00,'Магазин не открывается до 11 утра и не имеет службы автоответчика.'),(221,'WHEELS AND DEALS','2 MEMORIAL DRIVE','HOUSTON','TX','77007',713,5554139,7789,10000.00,'Магазин велосипедов и спортивных товаров со скидкой.'),(222,'JUST BIKES','4000 PARKRIDGE BLVD.','DALLAS','TX','75205',214,5558735,7789,4000.00,'Эксклюзивный дилер велосипедов.'),(223,'VELO SPORTS','23 WHITE ST.','MALDEN','MA','02148',617,5554983,7820,5000.00,'Клерк отвечает на все телефонные звонки.  Спроси Майка.'),(224,'JOE\'S BIKE SHOP','4500 FOX COURT','GRAND PRARIE','TX','75051',214,5559834,7789,6000.00,'Позвоните Джо, чтобы убедиться, что последняя партия была завершена.'),(225,'BOB\'S SWIM, CYCLE, AND RUN','300 HORSECREEK CIRCLE','IRVING','TX','75039',214,5558388,7789,7000.00,'Магазин, обслуживающий триатлетов.'),(226,'CENTURY SHOP','8 DAGMAR DR.','HUNTINGTON','NY','11743',516,5553006,7555,4000.00,'Клиент в разгар программы сокращения расходов.'),(227,'THE TOUR','2500 GARDNER RD.','SOMERVILLE','MA','02144',617,5556673,7820,5000.00,'Клиент обратился к нам по всей стране.'),(228,'FITNESS FIRST','5000 85TH ST.','JACKSON HEIGHTS','NY','11372',718,5558710,7555,4000.00,'Недавно приобрел еще один магазин спортивных товаров.  Ожидайте большего объема в будущем');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-24 12:05:45
